var tela = 0
var boneco; 
var BolaVitoria;
var Inimigos;
var StatusdoJogo = 'start';


function setup() {
  createCanvas(800, 400);
  noStroke();
  resetar();
  background(0); 
}

function preload() {
  img = loadImage('background.jpg')
  helo = loadImage('heloisa.jpeg')
}

function resetar(){
  
//local do bonequinho no resetar
  boneco = {
    x: 20,
    y: 20,
    w: 10,
    h: 10
  };

  // local de vitória
  BolaVitoria = []; 

  for(let i=0;i<1;i++) {
        BolaVitoria.push(new LocalVitoria());
  }
  
//obstáculos
  Inimigos = [];
  for(let i=0;i<150;i++) {
        Inimigos.push(new Inimigo());
  }
}

function draw() {
  background(img,220);
  
  if (tela == 0) {

  fill(920);
  textSize(50);
  textAlign(CENTER);
  text("ACERTE O BURACO!",400, 200);
  textSize(23);
  fill(0)
  textSize(22);
  text("Aperte '1' para jogar, '2' para instruções, '3' para créditos.",400, 240); 
}
  
    else if (tela == 1) {
  background(227, 101, 91);
  
//quadrado topo
  fill(255);
  rect(0, 0, 50, 50);
  
//boneco
  fill(255,183,173);
  rect(boneco.x, boneco.y, boneco.w, boneco.h);

//Chegar no local da vitória
   for(let i=0;i<BolaVitoria.length;i++) {
        BolaVitoria[i].show();
     let FimdeJogo = BolaVitoria[i];
     
//Fim de Jogo - Vitória
  for(let g of BolaVitoria) {
    let d = dist(boneco.x + boneco.w/2, boneco.y - boneco.h/2, g.x, g.y);
    if(d < boneco.w + g.r) {
tela = 5
      }
    }
  }
     
//Fim de jogo - Derrota
  for(let e of Inimigos) {
    e.show();
    d = dist(boneco.x, boneco.y, e.x, e.y);
      if(d<boneco.w && boneco.h + e.x) {
        tela=4
        }
      }   
    }
  
    else if (tela == 2) {
    textSize(23)
    fill(0)
    textStyle(BOLDITALIC)
    text("Mova o quadradinho utilizando as teclas",400, 170)
    text("'A,S,W,D'. Use 'R' para resetar. O objetivo é", 400, 200)
    text("alcançar o buraco (bola maior) sem ", 400,230)
    text("encostar nos obstáculos (bolas menores).",400,260)
    textSize(14)
    fill(920)
    text("ESC para voltar", 380, 380)
    }
  
    else if (tela == 3) {
    textSize(19)
    textFont('Georgia')
    text("Discente: Heloisa Pontes do Nascimento", 500,190)
    text("Turma: 05B", 380,220)
    text("Matrícula: 20210009642",435,250)
    textSize(14)
    fill(920)
    text("ESC para voltar", 380, 380)
    image (helo,100, 120, 200, 200)
    }

    else if (tela == 4) {
        fill(0);
        rect(0,0,800,400);
        fill(227, 101, 91);
        textSize(50);
        textAlign(CENTER);
        text("Você perdeu!",400, 200);
        textSize(12);
        textAlign(CENTER);
        text("Aperte 'R' para tentar novamente.",400, 250);
        StatusdoJogo = 'final_do_jogo';
        return
    }
 
     else if (tela == 5) {
      fill(0);
      rect(0,0,800,400);
      fill(227, 101, 91);
      textSize(50);
      textAlign(CENTER);
      text("Você ganhou! Parabéns!",400, 200);
      textSize(12);
      textAlign(CENTER);
      text("Aperte 'R' para resetar.",400, 250);
      StatusdoJogo = 'final_do_jogo';
      return;
    }       
        
              
        
}

class Inimigo {
  constructor() {
    this.x = random(width);
    this.y = random(height) + 60;
    this.r = 8;
  }
  show() {
    fill(0);
    circle(this.x,this.y,this.r);
    } 
}

class LocalVitoria {
  constructor() {
    this.x = random(width) + 40;
    this.y = random(height) + 40;
    this.r = 50;
  }
  show() {
    fill(181, 221, 164);
    circle(this.x,this.y,this.r);
  } 
}  


function keyPressed() {
  
  if(tela == 0){ 
    
  if(key ==='1'){
    tela=1;
  } 
    
  if(key ==='2'){
    tela=2;
  }    
    
  if(key ==='3'){
    tela=3;
  }  
    
  } else {
      
  if(tela == 1){
    if(key === 'w') {
    boneco.y -= 10;
    direcao = 0;
  }
	else if(key === 's') {
    boneco.y += 10;
    direcao = 1;
  }
    else if(key === 'a'){
    boneco.x -= 10;
    direcao = 3;
  }
    
    else if(key === 'd') {
    boneco.x += 10;
    direcao = 2;
  }
    
    else if(key ==='r'){
    resetar();
    tela = 1
    StatusdoJogo= 'jogando';
  }
    
    else if (key=="Escape")
    tela = 0

  } else {
    
    if(tela == 2){
 
    if (key=="Escape")
    tela = 0
     
  } else {
    
  if(tela == 3){
 
    if (key=="Escape")
    tela = 0
     
      }   
    
  if(tela == 4){
 
   
    if(key ==='r'){
    resetar();
    tela = 1
    StatusdoJogo= 'jogando';
  }
    
    if(key === 'Escape') {
    resetar();
    tela = 0
  }     
      }  
    
  if(tela == 5){
 
   
    if(key ==='r'){
    resetar();
    tela = 1
    StatusdoJogo= 'jogando';
  }
    
    if(key === 'Escape') {
    resetar();
    tela = 0
  }     
      }
  
    }  
  }
}
}